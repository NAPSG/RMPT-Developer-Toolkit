define({
  "default": {
    "name": "Per defecte",
    "description": "Per defecte"
  }
});