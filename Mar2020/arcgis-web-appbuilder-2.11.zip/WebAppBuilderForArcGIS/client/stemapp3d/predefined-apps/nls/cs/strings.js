define({
  "default": {
    "name": "výchozí",
    "description": "výchozí"
  }
});