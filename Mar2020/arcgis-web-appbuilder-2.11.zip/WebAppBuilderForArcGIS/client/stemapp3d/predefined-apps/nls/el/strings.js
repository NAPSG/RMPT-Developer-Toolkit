define({
  "default": {
    "name": "Προεπιλογή",
    "description": "Προεπιλογή"
  }
});