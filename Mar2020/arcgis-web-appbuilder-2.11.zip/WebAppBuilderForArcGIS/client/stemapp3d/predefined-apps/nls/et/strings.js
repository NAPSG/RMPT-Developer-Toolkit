define({
  "default": {
    "name": "Vaikimisi",
    "description": "Vaikimisi"
  }
});