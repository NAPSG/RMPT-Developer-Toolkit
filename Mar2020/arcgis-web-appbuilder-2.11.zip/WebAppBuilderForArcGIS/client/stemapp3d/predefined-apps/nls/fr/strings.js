define({
  "default": {
    "name": "Par défaut",
    "description": "Par défaut"
  }
});