define({
  "default": {
    "name": "ברירת מחדל",
    "description": "ברירת מחדל"
  }
});