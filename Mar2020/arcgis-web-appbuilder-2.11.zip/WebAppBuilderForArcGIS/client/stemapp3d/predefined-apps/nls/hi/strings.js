define({
  "default": {
    "name": "डिफॉल्ट",
    "description": "डिफॉल्ट"
  }
});