define({
  "default": {
    "name": "Alapértelmezett",
    "description": "Alapértelmezett"
  }
});