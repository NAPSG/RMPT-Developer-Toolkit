define({
  "default": {
    "name": "デフォルト",
    "description": "デフォルト"
  }
});