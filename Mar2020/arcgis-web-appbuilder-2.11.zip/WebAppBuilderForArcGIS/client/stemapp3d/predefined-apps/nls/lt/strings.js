define({
  "default": {
    "name": "Numatytasis",
    "description": "Numatytasis"
  }
});