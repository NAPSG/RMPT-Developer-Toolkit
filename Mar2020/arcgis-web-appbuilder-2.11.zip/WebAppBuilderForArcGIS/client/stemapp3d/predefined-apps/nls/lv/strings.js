define({
  "default": {
    "name": "Noklusējums",
    "description": "Noklusējums"
  }
});