define({
  "default": {
    "name": "Domyślne",
    "description": "Domyślne"
  }
});