define({
  "default": {
    "name": "Privzeto",
    "description": "Privzeto"
  }
});