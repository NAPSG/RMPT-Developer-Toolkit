define({
  "default": {
    "name": "Podrazumevano",
    "description": "Podrazumevano"
  }
});