define({
  "default": {
    "name": "ค่าตั้งต้น",
    "description": "ค่าตั้งต้น"
  }
});