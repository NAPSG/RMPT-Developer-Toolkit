define({
  "default": {
    "name": "Varsayılan",
    "description": "Varsayılan"
  }
});