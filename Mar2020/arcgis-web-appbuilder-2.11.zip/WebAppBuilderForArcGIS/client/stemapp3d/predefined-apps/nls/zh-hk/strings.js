define({
  "default": {
    "name": "預設",
    "description": "預設"
  }
});