define({
  "_themeLabel": "Tema Cartellera",
  "_layout_default": "Disseny per defecte",
  "_layout_right": "Disseny dret"
});