define({
  "_themeLabel": "Tema de Quadro de Aviso",
  "_layout_default": "Layout predefinido",
  "_layout_right": "Layout direita"
});