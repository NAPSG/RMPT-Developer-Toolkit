define({
  "_themeLabel": "Chủ đề Bảng thông báo",
  "_layout_default": "Bố cục mặc định",
  "_layout_right": "Bố cục bên phải"
});