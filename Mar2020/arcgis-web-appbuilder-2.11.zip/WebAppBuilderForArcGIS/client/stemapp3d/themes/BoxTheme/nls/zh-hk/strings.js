define({
  "_themeLabel": "方塊主題",
  "_layout_default": "預設版面配置",
  "_layout_top": "頂端版面配置"
});