define({
  "_widgetLabel": "Box-Controller"
});